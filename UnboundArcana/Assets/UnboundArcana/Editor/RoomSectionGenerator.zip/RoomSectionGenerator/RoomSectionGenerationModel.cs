using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace UnboundArcana.Core.Rooms.Editor
{
	public enum RoomSectionShapePreset
	{
		Rectangle,
		SideBay,
		EndBay,
		LShape,
		Random
	}

	public enum GeneratedBoundaryTopology
	{
		Straight,
		OuterTurn,
		InnerTurn,
		Cap
	}

	public enum GeneratedBoundaryHandedness
	{
		None,
		Left,
		Right
	}

	public enum RoomSectionDiagnosticSeverity
	{
		Error,
		Warning
	}

	[Serializable]
	public sealed class RoomSectionGenerationRequest
	{
		public int Seed = 12345;
		public RoomSectionShapePreset Preset = RoomSectionShapePreset.Random;
		public Vector2Int Size = new(10, 8);
		public Vector2Int ExtensionSize = new(2, 2);
		public int Extensions = 2;
		public bool Symmetric;

		public RoomSectionGenerationRequest Normalize()
		{
			Size = new Vector2Int(Mathf.Max(3, Size.x), Mathf.Max(3, Size.y));
			ExtensionSize = new Vector2Int(Mathf.Max(1, ExtensionSize.x), Mathf.Max(1, ExtensionSize.y));
			Extensions = Mathf.Max(0, Extensions);
			return this;
		}
	}

	public sealed class RoomSectionDiagnostic
	{
		public readonly RoomSectionDiagnosticSeverity Severity;
		public readonly string Message;
		public readonly Vector2Int? Cell;
		public readonly GeneratedWallDirection? Direction;

		public RoomSectionDiagnostic(RoomSectionDiagnosticSeverity severity, string message, Vector2Int? cell = null, GeneratedWallDirection? direction = null)
		{
			Severity = severity;
			Message = message;
			Cell = cell;
			Direction = direction;
		}

		public override string ToString()
		{
			string location = Cell.HasValue ? $" at {Cell.Value}" : string.Empty;
			string direction = Direction.HasValue ? $" {Direction.Value}" : string.Empty;
			return $"{Message}{direction}{location}";
		}
	}

	public sealed class GeneratedBoundaryVertex
	{
		public readonly Vector2Int Position;
		public readonly GeneratedBoundaryTopology Topology;

		public GeneratedBoundaryVertex(Vector2Int position, GeneratedBoundaryTopology topology)
		{
			Position = position;
			Topology = topology;
		}
	}

	public sealed class GeneratedBoundaryEdge
	{
		public readonly Vector2Int Cell;
		public readonly GeneratedWallDirection Direction;
		public readonly Vector2Int StartVertex;
		public readonly Vector2Int EndVertex;
		public readonly GeneratedBoundaryTopology Topology;
		public readonly GeneratedBoundaryHandedness Handedness;
		public readonly bool HasMultipleFeatures;

		public GeneratedBoundaryEdge(Vector2Int cell, GeneratedWallDirection direction, Vector2Int startVertex, Vector2Int endVertex, GeneratedBoundaryTopology topology, GeneratedBoundaryHandedness handedness, bool hasMultipleFeatures)
		{
			Cell = cell;
			Direction = direction;
			StartVertex = startVertex;
			EndVertex = endVertex;
			Topology = topology;
			Handedness = handedness;
			HasMultipleFeatures = hasMultipleFeatures;
		}
	}

	public sealed class RoomSectionShape
	{
		public readonly HashSet<Vector2Int> Cells = new();
		public readonly List<GeneratedBoundaryEdge> Boundaries = new();
		public readonly List<GeneratedBoundaryVertex> BoundaryVertices = new();
		public readonly List<RoomSectionDiagnostic> Diagnostics = new();

		public IEnumerable<RoomSectionDiagnostic> Errors => Diagnostics.Where(diagnostic => diagnostic.Severity == RoomSectionDiagnosticSeverity.Error);
		public IEnumerable<RoomSectionDiagnostic> Warnings => Diagnostics.Where(diagnostic => diagnostic.Severity == RoomSectionDiagnosticSeverity.Warning);
		public bool IsValid => !Errors.Any();
	}

	public static class RoomSectionShapeGenerationLogic
	{
		private readonly struct BoundaryKey : IEquatable<BoundaryKey>
		{
			public readonly Vector2Int Cell;
			public readonly GeneratedWallDirection Direction;

			public BoundaryKey(Vector2Int cell, GeneratedWallDirection direction)
			{
				Cell = cell;
				Direction = direction;
			}

			public bool Equals(BoundaryKey other)
			{
				return Cell == other.Cell && Direction == other.Direction;
			}

			public override bool Equals(object obj)
			{
				return obj is BoundaryKey other && Equals(other);
			}

			public override int GetHashCode()
			{
				return HashCode.Combine(Cell, Direction);
			}
		}

		private sealed class BoundaryVertexFeature
		{
			public GeneratedBoundaryTopology Topology;
		}

		public static RoomSectionShape Generate(RoomSectionGenerationRequest request)
		{
			request = request ?? new RoomSectionGenerationRequest();
			request.Normalize();
			RoomSectionShape result = new();
			System.Random random = new(request.Seed);
			CreateBaseShape(result.Cells, request, random);
			BuildBoundaries(result);
			Validate(result);
			return result;
		}

		private static void CreateBaseShape(HashSet<Vector2Int> cells, RoomSectionGenerationRequest request, System.Random random)
		{
			switch (request.Preset)
			{
				case RoomSectionShapePreset.SideBay:
					AddRectangle(cells, Vector2Int.zero, request.Size);
					AddBay(cells, request.Size, request.ExtensionSize, random.Next(4), random);
					break;
				case RoomSectionShapePreset.EndBay:
					AddRectangle(cells, Vector2Int.zero, request.Size);
					AddBay(cells, request.Size, request.ExtensionSize, random.Next(2) * 2, random);
					break;
				case RoomSectionShapePreset.LShape:
					AddLShape(cells, request.Size);
					break;
				case RoomSectionShapePreset.Random:
					AddRectangle(cells, Vector2Int.zero, request.Size);
					AddRandomBays(cells, request, random);
					break;
				default:
					AddRectangle(cells, Vector2Int.zero, request.Size);
					break;
			}
		}

		private static void AddRandomBays(HashSet<Vector2Int> cells, RoomSectionGenerationRequest request, System.Random random)
		{
			if (request.Symmetric)
			{
				int pairCount = (request.Extensions + 1) / 2;
				for (int i = 0; i < pairCount; i++)
				{
					int side = random.Next(2) == 0 ? 0 : 1;
					int maximumOffset = side == 0 ? request.Size.x - Mathf.Clamp(request.ExtensionSize.x, 1, request.Size.x) : request.Size.y - Mathf.Clamp(request.ExtensionSize.y, 1, request.Size.y);
					int offset = random.Next(0, Mathf.Max(1, maximumOffset + 1));
					AddBay(cells, request.Size, request.ExtensionSize, side, random, offset);
					AddBay(cells, request.Size, request.ExtensionSize, side == 0 ? 2 : 3, random, offset);
				}
				return;
			}
			for (int i = 0; i < request.Extensions; i++) AddBay(cells, request.Size, request.ExtensionSize, random.Next(4), random);
		}

		private static void AddBay(HashSet<Vector2Int> cells, Vector2Int baseSize, Vector2Int extensionSize, int side, System.Random random, int? requestedOffset = null)
		{
			int bayWidth = Mathf.Clamp(extensionSize.x, 1, baseSize.x);
			int bayHeight = Mathf.Clamp(extensionSize.y, 1, baseSize.y);
			int x = requestedOffset ?? random.Next(0, Mathf.Max(1, baseSize.x - bayWidth + 1));
			int y = requestedOffset ?? random.Next(0, Mathf.Max(1, baseSize.y - bayHeight + 1));
			switch (side)
			{
				case 0:
					AddRectangle(cells, new Vector2Int(x, baseSize.y), new Vector2Int(bayWidth, extensionSize.y));
					break;
				case 1:
					AddRectangle(cells, new Vector2Int(baseSize.x, y), new Vector2Int(extensionSize.x, bayHeight));
					break;
				case 2:
					AddRectangle(cells, new Vector2Int(x, -extensionSize.y), new Vector2Int(bayWidth, extensionSize.y));
					break;
				default:
					AddRectangle(cells, new Vector2Int(-extensionSize.x, y), new Vector2Int(extensionSize.x, bayHeight));
					break;
			}
		}

		private static void AddLShape(HashSet<Vector2Int> cells, Vector2Int size)
		{
			int splitX = Mathf.Max(1, size.x / 2);
			int splitY = Mathf.Max(1, size.y / 2);
			AddRectangle(cells, Vector2Int.zero, new Vector2Int(size.x, splitY));
			AddRectangle(cells, Vector2Int.zero, new Vector2Int(splitX, size.y));
		}

		private static void AddRectangle(HashSet<Vector2Int> cells, Vector2Int origin, Vector2Int size)
		{
			for (int x = 0; x < size.x; x++)
				for (int y = 0; y < size.y; y++)
					cells.Add(origin + new Vector2Int(x, y));
		}

		private static void BuildBoundaries(RoomSectionShape result)
		{
			HashSet<BoundaryKey> boundaryKeys = new();
			Dictionary<Vector2Int, List<BoundaryKey>> vertexEdges = new();
			foreach (Vector2Int cell in result.Cells)
				foreach ((Vector2Int offset, GeneratedWallDirection direction) side in GetSides())
				{
					if (result.Cells.Contains(cell + side.offset)) continue;
					BoundaryKey key = new(cell, side.direction);
					boundaryKeys.Add(key);
					foreach (Vector2Int vertex in GetVertices(cell, side.direction))
					{
						if (!vertexEdges.TryGetValue(vertex, out List<BoundaryKey> edges)) vertexEdges.Add(vertex, edges = new List<BoundaryKey>());
						edges.Add(key);
					}
				}
			Dictionary<Vector2Int, BoundaryVertexFeature> features = GetVertexFeatures(vertexEdges, result.Cells);
			foreach (KeyValuePair<Vector2Int, List<BoundaryKey>> vertex in vertexEdges.OrderBy(item => item.Key.x).ThenBy(item => item.Key.y))
				result.BoundaryVertices.Add(new GeneratedBoundaryVertex(vertex.Key, features.TryGetValue(vertex.Key, out BoundaryVertexFeature feature) ? feature.Topology : GeneratedBoundaryTopology.Straight));
			foreach (BoundaryKey key in boundaryKeys.OrderBy(item => item.Cell.x).ThenBy(item => item.Cell.y).ThenBy(item => item.Direction))
			{
				Vector2Int[] vertices = GetVertices(key.Cell, key.Direction);
				List<(Vector2Int Vertex, BoundaryVertexFeature Feature)> edgeFeatures = new();
				foreach (Vector2Int vertex in vertices) if (features.TryGetValue(vertex, out BoundaryVertexFeature feature)) edgeFeatures.Add((vertex, feature));
				GeneratedBoundaryTopology topology = GeneratedBoundaryTopology.Straight;
				GeneratedBoundaryHandedness handedness = GeneratedBoundaryHandedness.None;
				bool multipleFeatures = edgeFeatures.Count > 1;
				if (multipleFeatures)
				{
					topology = GeneratedBoundaryTopology.Cap;
				}
				else if (edgeFeatures.Count == 1)
				{
					topology = edgeFeatures[0].Feature.Topology;
					handedness = GetHandedness(key.Direction, vertices, edgeFeatures[0].Vertex);
				}
				result.Boundaries.Add(new GeneratedBoundaryEdge(key.Cell, key.Direction, vertices[0], vertices[1], topology, handedness, multipleFeatures));
			}
		}

		private static Dictionary<Vector2Int, BoundaryVertexFeature> GetVertexFeatures(Dictionary<Vector2Int, List<BoundaryKey>> vertexEdges, HashSet<Vector2Int> cells)
		{
			Dictionary<Vector2Int, BoundaryVertexFeature> result = new();
			foreach (KeyValuePair<Vector2Int, List<BoundaryKey>> vertex in vertexEdges)
			{
				List<GeneratedWallDirection> directions = vertex.Value.Select(edge => edge.Direction).Distinct().ToList();
				if (directions.Count != 2 || !IsCornerPair(directions[0], directions[1])) continue;
				GeneratedBoundaryTopology topology = GetCornerTopology(vertex.Key, cells);
				if (topology == GeneratedBoundaryTopology.Straight) continue;
				result[vertex.Key] = new BoundaryVertexFeature
				{
					Topology = topology
				};
			}
			return result;
		}

		private static void Validate(RoomSectionShape result)
		{
			if (result.Cells.Count == 0) result.Diagnostics.Add(new RoomSectionDiagnostic(RoomSectionDiagnosticSeverity.Error, "Generated shape is empty."));
			if (result.Boundaries.Count == 0) result.Diagnostics.Add(new RoomSectionDiagnostic(RoomSectionDiagnosticSeverity.Error, "Generated shape has no wall boundary."));
			if (result.Cells.Count == 0) return;
			HashSet<Vector2Int> visited = FloodFill(result.Cells.First(), result.Cells);
			if (visited.Count != result.Cells.Count) result.Diagnostics.Add(new RoomSectionDiagnostic(RoomSectionDiagnosticSeverity.Error, "Generated shape is disconnected."));
			if (HasHole(result.Cells)) result.Diagnostics.Add(new RoomSectionDiagnostic(RoomSectionDiagnosticSeverity.Error, "Generated shape contains a hole."));
			if (HasDiagonalOnlyContact(result.Cells)) result.Diagnostics.Add(new RoomSectionDiagnostic(RoomSectionDiagnosticSeverity.Error, "Generated shape contains diagonal-only contact."));
		}

		private static HashSet<Vector2Int> FloodFill(Vector2Int start, HashSet<Vector2Int> cells = null)
		{
			cells ??= new HashSet<Vector2Int>();
			HashSet<Vector2Int> visited = new();
			Queue<Vector2Int> queue = new();
			queue.Enqueue(start);
			while (queue.Count > 0)
			{
				Vector2Int cell = queue.Dequeue();
				if (!visited.Add(cell)) continue;
				foreach (Vector2Int offset in GetOffsets()) if (cells.Contains(cell + offset)) queue.Enqueue(cell + offset);
			}
			return visited;
		}

		private static bool HasHole(HashSet<Vector2Int> cells)
		{
			int minX = cells.Min(cell => cell.x) - 1;
			int maxX = cells.Max(cell => cell.x) + 1;
			int minY = cells.Min(cell => cell.y) - 1;
			int maxY = cells.Max(cell => cell.y) + 1;
			HashSet<Vector2Int> exterior = new();
			Queue<Vector2Int> queue = new();
			queue.Enqueue(new Vector2Int(minX, minY));
			while (queue.Count > 0)
			{
				Vector2Int cell = queue.Dequeue();
				if (!exterior.Add(cell) || cells.Contains(cell) || cell.x < minX || cell.x > maxX || cell.y < minY || cell.y > maxY) continue;
				foreach (Vector2Int offset in GetOffsets()) queue.Enqueue(cell + offset);
			}
			for (int x = minX + 1; x < maxX; x++)
				for (int y = minY + 1; y < maxY; y++)
					if (!cells.Contains(new Vector2Int(x, y)) && !exterior.Contains(new Vector2Int(x, y))) return true;
			return false;
		}

		private static bool HasDiagonalOnlyContact(HashSet<Vector2Int> cells)
		{
			foreach (Vector2Int cell in cells)
				foreach (Vector2Int diagonal in new[] { new Vector2Int(1, 1), new Vector2Int(1, -1) })
				{
					Vector2Int other = cell + diagonal;
					if (!cells.Contains(other)) continue;
					if (!cells.Contains(cell + new Vector2Int(diagonal.x, 0)) && !cells.Contains(cell + new Vector2Int(0, diagonal.y))) return true;
				}
			return false;
		}

		private static IEnumerable<Vector2Int> GetOffsets()
		{
			yield return Vector2Int.up;
			yield return Vector2Int.right;
			yield return Vector2Int.down;
			yield return Vector2Int.left;
		}

		private static IEnumerable<(Vector2Int Offset, GeneratedWallDirection Direction)> GetSides()
		{
			yield return (Vector2Int.up, GeneratedWallDirection.North);
			yield return (Vector2Int.right, GeneratedWallDirection.East);
			yield return (Vector2Int.down, GeneratedWallDirection.South);
			yield return (Vector2Int.left, GeneratedWallDirection.West);
		}

		private static Vector2Int[] GetVertices(Vector2Int cell, GeneratedWallDirection direction)
		{
			return direction switch
			{
				GeneratedWallDirection.North => new[] { cell + Vector2Int.up, cell + Vector2Int.up + Vector2Int.right },
				GeneratedWallDirection.East => new[] { cell + Vector2Int.up + Vector2Int.right, cell + Vector2Int.right },
				GeneratedWallDirection.South => new[] { cell + Vector2Int.right, cell },
				_ => new[] { cell, cell + Vector2Int.up }
			};
		}

		private static GeneratedBoundaryHandedness GetHandedness(GeneratedWallDirection direction, Vector2Int[] vertices, Vector2Int featureVertex)
		{
			bool horizontal = direction == GeneratedWallDirection.North || direction == GeneratedWallDirection.South;
			int minimum = horizontal ? Mathf.Min(vertices[0].x, vertices[1].x) : Mathf.Min(vertices[0].y, vertices[1].y);
			bool left = horizontal ? featureVertex.x == minimum : featureVertex.y == minimum;
			return left ? GeneratedBoundaryHandedness.Left : GeneratedBoundaryHandedness.Right;
		}

		private static GeneratedBoundaryTopology GetCornerTopology(Vector2Int vertex, HashSet<Vector2Int> cells)
		{
			int occupied = 0;
			foreach (Vector2Int cell in new[] { vertex + new Vector2Int(-1, -1), vertex + Vector2Int.down, vertex + Vector2Int.left, vertex }) if (cells.Contains(cell)) occupied++;
			if (occupied == 1) return GeneratedBoundaryTopology.OuterTurn;
			if (occupied == 3) return GeneratedBoundaryTopology.InnerTurn;
			return GeneratedBoundaryTopology.Straight;
		}

		private static bool IsCornerPair(GeneratedWallDirection first, GeneratedWallDirection second)
		{
			return first != second && ((int)first + (int)second) % 2 == 1;
		}

	}
}
