using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace UnboundArcana.Core.Rooms.Editor
{
	public enum RoomSectionRenderPass
	{
		OtherWalls,
		SouthWalls
	}

	[CreateAssetMenu(menuName = "Unbound Arcana/Rooms/Room Section Style Profile")]
	public sealed class RoomSectionStyleProfile : ScriptableObject
	{
		public Vector3 CellSize = new(0.3f, 0.3f, 0.3f);
		public bool RequireSquareCells = true;
		public int SouthWallSortingOrder = 1;
		public int OtherWallSortingOrder = 3;
		public TileBase FloorTile;
		public TileBase DebugFallbackTile;
		public int NorthWallLayerCount = 1;
		public int EastWallLayerCount = 1;
		public int SouthWallLayerCount = 1;
		public int WestWallLayerCount = 1;
		public List<RoomSectionWallVisualMapping> WallMappings = new();

		public int GetLayerCount(GeneratedWallDirection direction)
		{
			return Mathf.Max(1, direction switch
			{
				GeneratedWallDirection.North => NorthWallLayerCount,
				GeneratedWallDirection.East => EastWallLayerCount,
				GeneratedWallDirection.South => SouthWallLayerCount,
				_ => WestWallLayerCount
			});
		}

		public bool TryGetTile(GeneratedBoundaryEdge edge, int layer, out TileBase tile)
		{
			return TryGetTile(edge, layer, out tile, out _);
		}

		public bool TryGetTile(GeneratedBoundaryEdge edge, int layer, out TileBase tile, out RoomSectionRenderPass renderPass)
		{
			RoomSectionRenderPass defaultPass = GetDefaultRenderPass(edge.Direction);
			RoomSectionWallVisualMapping mapping = WallMappings.Where(item => item != null && item.Direction == edge.Direction && item.Topology == edge.Topology && item.Handedness == edge.Handedness && item.Layer == layer).OrderByDescending(item => item.TargetPass == defaultPass).FirstOrDefault();
			tile = mapping == null ? null : mapping.Tile;
			renderPass = mapping == null ? GetDefaultRenderPass(edge.Direction) : mapping.TargetPass;
			return tile != null;
		}

		public static RoomSectionRenderPass GetDefaultRenderPass(GeneratedWallDirection direction)
		{
			return direction == GeneratedWallDirection.South ? RoomSectionRenderPass.SouthWalls : RoomSectionRenderPass.OtherWalls;
		}

		public List<string> ValidateProfile()
		{
			List<string> diagnostics = new();
			if (CellSize.x <= 0f || CellSize.y <= 0f || CellSize.z <= 0f) diagnostics.Add("Grid cell size must be positive.");
			if (RequireSquareCells && !Mathf.Approximately(CellSize.x, CellSize.y)) diagnostics.Add("Grid X and Y cell size must match.");
			if (FloorTile == null) diagnostics.Add("Floor tile is missing.");
			if (NorthWallLayerCount < 1 || EastWallLayerCount < 1 || SouthWallLayerCount < 1 || WestWallLayerCount < 1) diagnostics.Add("Every wall direction must have at least one layer.");
			HashSet<string> keys = new();
			foreach (RoomSectionWallVisualMapping mapping in WallMappings)
			{
				if (mapping == null) continue;
				string key = $"{mapping.Direction}:{mapping.Topology}:{mapping.Handedness}:{mapping.Layer}:{mapping.TargetPass}";
				if (!keys.Add(key)) diagnostics.Add($"Duplicate wall mapping: {key}.");
				if (mapping.Layer < 0) diagnostics.Add($"Wall mapping layer cannot be negative: {key}.");
				if (mapping.Tile == null) diagnostics.Add($"Wall mapping has no tile: {key}.");
			}
			return diagnostics;
		}
}

	[Serializable]
	public sealed class RoomSectionWallVisualMapping
	{
		public GeneratedWallDirection Direction;
		public GeneratedBoundaryTopology Topology;
		public GeneratedBoundaryHandedness Handedness;
		public int Layer;
		public RoomSectionRenderPass TargetPass;
		public TileBase Tile;
	}

	public sealed class RoomSectionPreviewResult
	{
		public readonly GameObject Root;
		public readonly List<RoomSectionDiagnostic> Diagnostics = new();

		public IEnumerable<RoomSectionDiagnostic> Errors => Diagnostics.Where(diagnostic => diagnostic.Severity == RoomSectionDiagnosticSeverity.Error);
		public IEnumerable<RoomSectionDiagnostic> Warnings => Diagnostics.Where(diagnostic => diagnostic.Severity == RoomSectionDiagnosticSeverity.Warning);

		public RoomSectionPreviewResult(GameObject root)
		{
			Root = root;
		}
	}
}
