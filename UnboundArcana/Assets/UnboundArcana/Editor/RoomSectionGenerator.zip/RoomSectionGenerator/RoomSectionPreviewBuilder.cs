using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace UnboundArcana.Core.Rooms.Editor
{
	public static class RoomSectionPreviewBuilder
	{
		public static RoomSectionPreviewResult Build(RoomSectionShape shape, RoomSectionStyleProfile profile, string name)
		{
			GameObject root = new(name);
			Grid grid = root.AddComponent<Grid>();
			grid.cellSize = profile == null ? new Vector3(0.3f, 0.3f, 0.3f) : profile.CellSize;
			RoomSection section = root.AddComponent<RoomSection>();
			RoomSectionFootprint footprint = root.AddComponent<RoomSectionFootprint>();
			GameObject floorObject = CreateTilemap(root.transform, "Floor", 0, false);
			Tilemap floor = floorObject.GetComponent<Tilemap>();
			RoomSectionPreviewResult result = new(root);
			foreach (RoomSectionDiagnostic diagnostic in shape.Diagnostics) result.Diagnostics.Add(diagnostic);
			if (profile == null) result.Diagnostics.Add(new RoomSectionDiagnostic(RoomSectionDiagnosticSeverity.Warning, "No style profile assigned. The preview is geometry-only."));
			else foreach (string diagnostic in profile.ValidateProfile()) result.Diagnostics.Add(new RoomSectionDiagnostic(RoomSectionDiagnosticSeverity.Warning, diagnostic));
			if (profile != null && profile.FloorTile != null)
			{
				foreach (Vector2Int cell in shape.Cells) floor.SetTile(new Vector3Int(cell.x, cell.y, 0), profile.FloorTile);
				floor.RefreshAllTiles();
			}
			int southOrder = profile == null ? 1 : profile.SouthWallSortingOrder;
			int otherOrder = profile == null ? 3 : profile.OtherWallSortingOrder;
			GameObject southObject = CreateTilemap(root.transform, "Walls_South", southOrder, true);
			GameObject otherObject = CreateTilemap(root.transform, "Walls_Other", otherOrder, true);
			BuildWalls(shape, profile, southObject.GetComponent<Tilemap>(), otherObject.GetComponent<Tilemap>(), result);
			SerializedObject serialized = new(section);
			serialized.FindProperty("sectionId").stringValue = name;
			serialized.FindProperty("grid").objectReferenceValue = grid;
			serialized.FindProperty("footprint").objectReferenceValue = footprint;
			serialized.FindProperty("connectors").arraySize = 0;
			serialized.FindProperty("props").arraySize = 0;
			serialized.ApplyModifiedPropertiesWithoutUndo();
			SetFootprint(footprint, shape.Cells);
			RoomSectionGeneratorSceneOverlay.Set(root, shape, result.Diagnostics);
			return result;
		}

		private static void BuildWalls(RoomSectionShape shape, RoomSectionStyleProfile profile, Tilemap south, Tilemap other, RoomSectionPreviewResult result)
		{
			foreach (GeneratedBoundaryEdge edge in shape.Boundaries)
			{
				if (edge.HasMultipleFeatures) result.Diagnostics.Add(new RoomSectionDiagnostic(RoomSectionDiagnosticSeverity.Warning, "Boundary segment has corner features at both endpoints and requires a compound tile.", edge.Cell, edge.Direction));
				int layerCount = profile == null ? 1 : profile.GetLayerCount(edge.Direction);
				for (int layer = 0; layer < layerCount; layer++)
				{
					TileBase tile = null;
					RoomSectionRenderPass renderPass = RoomSectionStyleProfile.GetDefaultRenderPass(edge.Direction);
					if (profile != null && profile.TryGetTile(edge, layer, out TileBase mappedTile, out RoomSectionRenderPass mappedPass))
					{
						tile = mappedTile;
						renderPass = mappedPass;
					}
					if (tile == null)
					{
						if (profile != null) tile = profile.DebugFallbackTile;
						result.Diagnostics.Add(new RoomSectionDiagnostic(RoomSectionDiagnosticSeverity.Warning, $"Missing visual mapping for {edge.Direction} {edge.Topology} {edge.Handedness} layer {layer}.", edge.Cell, edge.Direction));
					}
					if (tile == null) continue;
					Tilemap target = renderPass == RoomSectionRenderPass.SouthWalls ? south : other;
					target.SetTile(new Vector3Int(edge.Cell.x, edge.Cell.y + layer, 0), tile);
				}
			}
		}

		private static GameObject CreateTilemap(Transform parent, string name, int order, bool collider)
		{
			GameObject obj = new(name);
			obj.transform.SetParent(parent);
			obj.AddComponent<Tilemap>();
			TilemapRenderer renderer = obj.AddComponent<TilemapRenderer>();
			renderer.sortingOrder = order;
			if (collider) obj.AddComponent<TilemapCollider2D>();
			return obj;
		}

		private static void SetFootprint(RoomSectionFootprint footprint, HashSet<Vector2Int> cells)
		{
			SerializedObject serialized = new(footprint);
			SerializedProperty rectangles = serialized.FindProperty("rectangles");
			List<FootprintRectangle> rows = new();
			foreach (int y in cells.Select(cell => cell.y).Distinct().OrderBy(value => value))
			{
				List<int> xs = cells.Where(cell => cell.y == y).Select(cell => cell.x).OrderBy(value => value).ToList();
				int start = xs[0];
				int previous = start;
				for (int i = 1; i <= xs.Count; i++)
				{
					if (i < xs.Count && xs[i] == previous + 1) { previous = xs[i]; continue; }
					rows.Add(new FootprintRectangle { Position = new Vector2Int(start, y), Size = new Vector2Int(previous - start + 1, 1) });
					if (i < xs.Count) start = previous = xs[i];
				}
			}
			rectangles.arraySize = rows.Count;
			for (int i = 0; i < rows.Count; i++)
			{
				SerializedProperty rectangle = rectangles.GetArrayElementAtIndex(i);
				rectangle.FindPropertyRelative("Position").vector2IntValue = rows[i].Position;
				rectangle.FindPropertyRelative("Size").vector2IntValue = rows[i].Size;
			}
			serialized.ApplyModifiedPropertiesWithoutUndo();
		}
	}

	[InitializeOnLoad]
	internal static class RoomSectionGeneratorSceneOverlay
	{
		private static GameObject activeRoot;
		private static RoomSectionShape activeShape;
		private static List<RoomSectionDiagnostic> activeDiagnostics;

		static RoomSectionGeneratorSceneOverlay()
		{
			SceneView.duringSceneGui += Draw;
		}

		public static void Set(GameObject root, RoomSectionShape shape, IEnumerable<RoomSectionDiagnostic> diagnostics)
		{
			activeRoot = root;
			activeShape = shape;
			activeDiagnostics = diagnostics.ToList();
			SceneView.RepaintAll();
		}

		public static void Clear(GameObject root)
		{
			if (activeRoot != root) return;
			activeRoot = null;
			activeShape = null;
			activeDiagnostics = null;
			SceneView.RepaintAll();
		}

		private static void Draw(SceneView sceneView)
		{
			if (activeRoot == null || activeShape == null || Selection.activeGameObject != activeRoot) return;
			Grid grid = activeRoot.GetComponent<Grid>();
			if (grid == null) return;
			Handles.color = new Color(1f, 0.75f, 0.1f, 0.8f);
			foreach (RoomSectionDiagnostic diagnostic in activeDiagnostics ?? new List<RoomSectionDiagnostic>())
			{
				if (!diagnostic.Cell.HasValue) continue;
				Vector3 center = grid.GetCellCenterWorld(new Vector3Int(diagnostic.Cell.Value.x, diagnostic.Cell.Value.y, 0));
				Handles.DrawWireCube(center, grid.cellSize * 0.9f);
			}
		}
	}
}
