---
name: review-change
description: Review an existing code change, diff or implementation for correctness, regressions, ownership, lifecycle and maintainability. Report actionable findings only; do not modify code.
---
# Review Change

Review the change against its intended behavior and surrounding code.

Do not modify files.

## Check

Prioritize:

1. incorrect behavior
2. regressions
3. ownership/lifecycle errors
4. invalid assumptions or edge cases
5. Unity-specific hazards
6. unnecessary complexity or architectural divergence

Inspect enough surrounding code to understand the changed execution path.

Use `Design/INDEX.md` when the change may violate documented architecture or game-design intent.

## Findings

Report only issues that justify action.

For each finding provide:

* severity
* location
* failure scenario
* why it matters
* smallest reasonable correction

Do not report:

* cosmetic preferences
* speculative future problems
* harmless style differences
* refactors without concrete benefit

If no meaningful issue is found, say so.

Do not invent findings to fill the review.
