---
name: game-design
description: Design or evolve gameplay systems for Unbound Arcana from player experience first. Align proposals with the core pillars, existing systems and solo-development scope before considering implementation.
---

# Game Design

Use for new mechanics, systems, content structures or substantial gameplay changes.

Read `Design/GameVision.md`.

Read `Design/CurrentState.md` when the proposal depends on current project maturity.

Use `Design/INDEX.md` for additional context only when needed.

## Start With Experience

Define:

* player problem or opportunity
* desired player behavior/feeling
* decisions the system creates
* how it supports the core pillars

Do not begin from classes or architecture.

## Design

Prefer mechanics that:

* create meaningful choices
* interact with existing systems
* support experimentation
* produce multiple situations from limited content
* remain understandable to the player

Consider both novice discovery and experienced mastery.

Preserve roguelike uncertainty without removing player agency.

## Scope

Assume solo-development constraints.

Prefer:

* small systemic mechanics
* authored components with combinatorial value
* incremental prototypes
* extensions of existing systems

Avoid:

* large frameworks before validation
* content-heavy solutions to systemic problems
* complexity without player-facing value
* solving future requirements prematurely

## Output

Provide:

1. design goal
2. proposed player loop/mechanic
3. why it supports the game
4. important tradeoffs/risks
5. smallest useful prototype
6. what the prototype should validate

Do not implement unless explicitly asked.
