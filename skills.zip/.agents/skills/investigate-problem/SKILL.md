---
name: investigate-problem
description: Investigate a bug, unexpected behavior, performance issue or unclear execution path. Find evidence and root cause before proposing changes. Do not modify code unless explicitly requested.
---

# Investigate Problem

Use when the cause is unknown.

Default mode is read-only.

## Workflow

1. Define the observed symptom and expected behavior.
2. Trace the relevant execution path from entry point to failure.
3. Inspect state ownership, lifecycle, events and callers involved.
4. Gather evidence before forming conclusions.
5. Separate confirmed facts from hypotheses.
6. Identify the smallest root cause that explains the evidence.
7. Propose a focused fix and relevant validation.

Use `Design/INDEX.md` only when architecture or intended behavior is necessary to determine what is wrong.

## Rules

* Do not modify code unless explicitly asked.
* Do not treat suspicious code as proof.
* Prefer one evidence-backed root cause over many speculative possibilities.
* Consider Unity lifecycle, destroyed objects, initialization order, subscriptions, scene transitions and mutable runtime state when relevant.
* Distinguish root cause from secondary symptoms.
* Avoid proposing broad refactors unless the root cause requires one.

## Finish

Report:

* root cause, or strongest remaining hypothesis
* supporting evidence
* affected path
* recommended fix
* how to verify it
