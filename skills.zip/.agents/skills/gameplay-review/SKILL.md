---
name: gameplay-review
description: Analyze existing gameplay for fun, feel, pacing, decisions, pressure, feedback, repetition and build expression. Diagnose player-experience problems before proposing changes. Do not modify code.
---

# Gameplay Review

Evaluate gameplay from the player's perspective.

Read `Design/GameVision.md` and `Design/CurrentState.md` when evaluating a substantial gameplay area.

Inspect relevant implementation only to understand what produces the experience.

## Evaluate

Consider where relevant:

* moment-to-moment feel
* responsiveness and feedback
* meaningful decisions
* spatial/tactical pressure
* repetition
* pacing
* challenge vs frustration
* player skill expression
* build expression
* readability
* interaction with the core pillars

Ask what the player is repeatedly doing, deciding and learning.

## Diagnose

Separate:

* symptom
* likely cause
* evidence
* design consequence

Do not assume more content solves weak gameplay.

Distinguish problems of:

* mechanics
* tuning
* feedback/presentation
* encounter composition
* pacing
* missing decisions

## Recommend

Prioritize a small number of high-impact changes or experiments.

Prefer cheap tests that validate the diagnosis before large systems or content production.

Do not modify code unless explicitly asked to move from review to implementation.
