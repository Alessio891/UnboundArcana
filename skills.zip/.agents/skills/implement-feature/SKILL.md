---
name: implement-feature
description: Implement a defined feature or behavior in the existing Unity project. Inspect current code, preserve ownership and patterns, make focused changes, and validate them.
---
# Implement Feature

Use for a defined implementation task.

## Workflow

1. Inspect the relevant code, callers and ownership before editing.
2. Use `Design/INDEX.md` only when project documentation can materially affect the solution.
3. Identify the smallest coherent change.
4. Reuse existing systems, contracts and patterns where appropriate.
5. Implement the complete requested behavior without unrelated refactoring.
6. Validate the affected path using available practical checks.

## Rules

* Do not design a new framework when an existing owner can support the feature.
* Do not implement hypothetical future requirements.
* Preserve Runtime / Editor boundaries.
* Keep authored configuration separate from mutable runtime state.
* Respect lifecycle and event ownership.
* Avoid hidden coupling between unrelated systems.
* If the requested design conflicts with an established invariant, surface the conflict before bypassing it.
* Follow local code style.

## Finish

Report only:

* changed behavior/files
* important implementation decisions
* validation performed
* unresolved concrete risks
